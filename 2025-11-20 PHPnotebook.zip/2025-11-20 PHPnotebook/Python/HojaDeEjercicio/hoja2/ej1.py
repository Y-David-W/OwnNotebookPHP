# ESCRIBE SI UN NÚMERO ES PAR IMPAR O CERO

print ("Escribe un número")

num = int(input())

if(num > 0):
    print("Es un número positivo")
elif(num < 0):
    print("Es un número negativo")
else:
    print("Es 0")