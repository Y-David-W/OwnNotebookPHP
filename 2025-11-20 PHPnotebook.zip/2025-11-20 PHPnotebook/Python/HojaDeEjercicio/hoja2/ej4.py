# Escribe un programa que pieda 5 número y diga cuánto es mayor que 10
num = []

for i in range (5):
    print(f"Escribe el número {i+1}")

    num.append(int(input()))
"""
for i in num:
    print(i)
"""
contador = 0

for i in num:
    if(i > 10):
        print(i, end=" ")
        contador+=1
    
print(f"Estos {contador} números es mayor que 10")