#COMPROBAR SI UN NÚMERO ES PAR O IMPART

print("Escribe un número")

num = int(input())

if(num/2 % 1):
    print("Es impar")
else:
    print("Es par")
