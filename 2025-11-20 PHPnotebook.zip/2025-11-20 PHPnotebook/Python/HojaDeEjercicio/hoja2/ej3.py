# FACTORIAL DE UN NÚMERO CON WHILE

print("Escribe un número")
num = int(input())
i = 1
while (i<= num):
    print (i , end=" ")
    i+=1