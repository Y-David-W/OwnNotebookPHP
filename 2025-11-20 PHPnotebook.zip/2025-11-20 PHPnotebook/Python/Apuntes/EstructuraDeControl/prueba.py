def prueba():
    a = int(input)


print("Suma 2 numeros")


# SUMA 2 NUMEROS
print("Escribe el número a")
a = int(input())
print("Escribe el número b")
b = int(input())
c = "la suma de "
print(f"{c}{a}+{b} = {a+b}")

x = 4;y = 5
print (x+y)