# Creación de una tupla
informacion_persona = ("Ana", 30, "Madrid")

# Acceso a los elementos (inmutables)
nombre = informacion_persona[0]
edad = informacion_persona[1]

print(f"Nombre: {nombre}, Edad: {edad}")
# Salida: Nombre: Ana, Edad: 30

# Intentar modificar un elemento generará un error
# informacion_persona[1] = 31 # Esto produciría un TypeError






# Creación de una lista (array)
numeros = [1, 2, 3, 4, 5]

# Acceso a los elementos
primer_numero = numeros[0]

print(f"Primer número: {primer_numero}")
# Salida: Primer número: 1

# Modificación de un elemento
numeros[1] = 20
print(f"Lista modificada: {numeros}")
# Salida: Lista modificada: [1, 20, 3, 4, 5]

# Adición de un elemento
numeros.append(6)
print(f"Lista con nuevo elemento: {numeros}")
# Salida: Lista con nuevo elemento: [1, 20, 3, 4, 5, 6]
