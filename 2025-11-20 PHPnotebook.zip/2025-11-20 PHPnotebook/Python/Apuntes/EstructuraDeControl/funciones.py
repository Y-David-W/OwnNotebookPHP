frase = "hola mundo"

print(frase.upper())
print(frase)