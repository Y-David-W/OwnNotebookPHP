print("Escribe un numero")
a = int(input())

match a:
    case 1:
        print("Es uno")
    case 2:
        print("Es dos")
    case _:
        print("Por defecto")