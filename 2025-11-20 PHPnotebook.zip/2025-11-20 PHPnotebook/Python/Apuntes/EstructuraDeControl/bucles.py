# BUCLE WHILE

n = 1
while n <= 5 :  
    print("El número es " , n)

    # n = n+1
    n +=1

# Ejemplo con un argumento
for i in range(6):
    """
    if i == 2: # SALTA SI ES 2
        continue 
    print(i, end= (" "))
    """
    print(i)

for i in range(1,6):
    print(i, end= (" "))
print()