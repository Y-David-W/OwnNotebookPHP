# Def es como un clase

def saludar():
    print("hola mundo")

saludar()