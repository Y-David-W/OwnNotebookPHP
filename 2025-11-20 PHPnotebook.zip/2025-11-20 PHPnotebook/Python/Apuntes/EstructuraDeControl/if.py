a = 5 
if a == 5:
    print ("no es 5")
    
print ("Escribe tu edad")
edad = int(input())

if edad <= 17:
    print("Eres menor de edad")
elif edad <= 30:
    print("Eres mayor de edad")
elif edad:
    print("Eres adulto")