
n = int(input("Escribe hasta donde contar: "))
for i in range(1, n+1):
    print(i, end=" ")


"""
print("Escribe hasta donde contar")
n = int(input())

n = int(input("Escribe hasta donde contar: "))

def contar_hasta():
    n = int(input("Escribe hasta donde contar: "))
    for i in range(1, n + 1):
        print(i, end=" ")

contar_hasta()

"""
