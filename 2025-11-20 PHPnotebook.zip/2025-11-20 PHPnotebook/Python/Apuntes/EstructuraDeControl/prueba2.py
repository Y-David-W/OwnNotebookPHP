a, b = 4, "aaa"
print(a, b)