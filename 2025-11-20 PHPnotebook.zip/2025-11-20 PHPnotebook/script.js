function toggleFolder(el) {
    event.stopPropagation();
    const ul = el.querySelector("ul");
    if (!ul) return;

    const icon = el.querySelector('.icon');

    const isOpen = el.classList.contains('open');
    ul.style.height = isOpen ? ul.scrollHeight + "px" : "0px";
    ul.offsetHeight; // efecto al abrir/ flow when open

    if (isOpen) {
        ul.style.height = "0px";
        ul.style.opacity = "0";
        el.classList.remove('open');
        if (icon) icon.textContent = "📁"; // Carpeta cerrada/closed folder emoji
    } else {
        ul.style.opacity = "1";
        ul.style.height = ul.scrollHeight + "px";
        el.classList.add('open');
        if (icon) icon.textContent = "📂"; // Carpeta abierta/open folder emoji
        ul.addEventListener('transitionend', function ajustarAltura() {
            if (el.classList.contains('open')) ul.style.height = 'auto';
            ul.removeEventListener('transitionend', ajustarAltura);
        });
    }
}

// Evitar que el clic en un enlace dentro de folder cierre la carpeta/don't close folder when click a link
document.querySelectorAll('.folder a').forEach(link => {
    link.addEventListener('click', e => {
        e.stopPropagation(); // El click en el enlace no afectará el toggle
    });
});


document.addEventListener('DOMContentLoaded', () => {

    // Evitar cierre accidental al seleccionar texto dentro del preview/Don't close when preview
    ['mousedown', 'mouseup', 'click', 'selectstart', 'mousemove'].forEach(evt => {
        document.addEventListener(evt, e => {
            if (e.target.closest('.preview-content')) e.stopPropagation();
        }, true);
    });

    document.querySelectorAll('button.preview-btn').forEach(btn => {
        btn.addEventListener('click', async e => {
            e.stopPropagation();
            const id = btn.dataset.id;
            const carpeta = btn.dataset.carpeta;
            const archivo = btn.dataset.archivo;
            const extension = btn.dataset.extension;
            const preElem = document.getElementById('preview-' + id);
            const liPadre = btn.closest('li.file');
            if (!preElem) return;

            // Cierra otras previsualizaciones/close preview
            document.querySelectorAll('.preview-content.show').forEach(pre => {
                if (pre !== preElem) {
                    pre.classList.remove('show');
                    pre.parentElement?.classList.remove('preview-open');
                }
            });

            if (preElem.classList.contains('show')) {
                preElem.classList.remove('show');
                liPadre.classList.remove('preview-open');
                return;
            }

            btn.disabled = true;
            btn.textContent = '⏳';

            try {
                const resp = await fetch(`?previsualizar=1&carpeta=${encodeURIComponent(carpeta)}&archivo=${encodeURIComponent(archivo)}`);
                const data = await resp.json();

                if (data.error) {
                    preElem.textContent = "Error: " + data.error;
                } 
                else if (data.imagen) {
                    preElem.innerHTML = `<img src="${data.imagen}" alt="Imagen previsualizada">`;
                } 
                else if (data.pdf) {
                    // Mostrar PDF, DOC, ODT embebido/Show preview
                    preElem.innerHTML = `
                        <embed src="${data.pdf}" 
                               type="application/pdf" 
                               width="100%" height="400px" 
                               style="border-radius:6px; background:#fff;">
                    `;
                } 
                else if (data.contenido) {
                    let lang = {
                        php: 'php', py: 'python', js: 'javascript',
                        html: 'html', htm: 'html'
                    }[extension] || 'plaintext';

                    preElem.innerHTML = `<pre><code class="language-${lang}">${escapeHtml(data.contenido)}</code></pre>`;
                    hljs.highlightElement(preElem.querySelector('code'));
                } 
                else {
                    preElem.textContent = "No hay contenido para mostrar.";
                }

                preElem.classList.add('show');
                liPadre.classList.add('preview-open');

            } catch (err) {
                preElem.textContent = "Error al cargar contenido.";
                preElem.classList.add('show');
                liPadre.classList.add('preview-open');
            } finally {
                btn.disabled = false;
                btn.textContent = '🔍';
            }
        });
    });
});

function escapeHtml(str) {
    return str.replace(/&/g, "&amp;")
              .replace(/</g, "&lt;")
              .replace(/>/g, "&gt;");
}

hljs.highlightAll();

// BUSCADOR EN TIEMPO REAL/SEARCH BAR IN REAL TIME
document.getElementById('search-input').addEventListener('input', function() {
    const filtro = this.value.toLowerCase().trim();
    const carpetas = document.querySelectorAll('#tree-container > .folder');

    carpetas.forEach(folder => {
        function filtrarFolder(element) {
            let hayCoincidencia = false;

            // Revisar archivos dentro de la carpeta
            const archivos = element.querySelectorAll(':scope > ul > li.file');
            archivos.forEach(file => {
                const nombreArchivo = file.querySelector('.file-name-preview').textContent.toLowerCase();
                if (nombreArchivo.includes(filtro)) {
                    file.style.display = '';
                    hayCoincidencia = true;
                } else {
                    file.style.display = 'none';
                }
            });

            // Revisar subcarpetas recursivamente/view each subfolder
            const subfolders = element.querySelectorAll(':scope > ul > li.folder');
            subfolders.forEach(sub => {
                const subCoincide = filtrarFolder(sub);
                if (subCoincide) hayCoincidencia = true;
            });

            // Revisar nombre de la carpeta/check name
            const nombreCarpeta = element.querySelector(':scope > .folder-header > .folder-name').textContent.toLowerCase();
            if (nombreCarpeta.includes(filtro)) {
                hayCoincidencia = true;
                // Mostrar todos los hijos aunque no coincidan/show if is same
                element.querySelectorAll(':scope > ul > li').forEach(child => child.style.display = '');
            }

            // Mostrar u ocultar carpeta/don't show other folder
            element.style.display = hayCoincidencia ? '' : 'none';

            return hayCoincidencia;
        }

        filtrarFolder(folder);
    });
});


