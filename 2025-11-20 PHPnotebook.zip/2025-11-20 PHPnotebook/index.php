<?php
// CONFIGURACIÓN/SETTING
/**
 Puedes añadir carpetas de otras asignaturas como Java
 You can add other subject like Java
 */
$carpetas = ["PHP", "Python", "JavaScript", "Otros"];

// FUNCIONES/FUNCTION
function mostrarEstructura($rutaBase, $carpetaActual) {
	/**
     * Recorre los archivos y las sub carpetas
     * Browse the files and subfolders
     */
    $archivos = scandir($rutaBase);
    echo "<ul>";
    foreach ($archivos as $archivo) {
        if ($archivo === "." || $archivo === "..") continue;
        $rutaCompleta = "$rutaBase/$archivo";
        if (is_dir($rutaCompleta)) {
            echo "<li class='folder' onclick='toggleFolder(this)'>";
            echo "<div class='folder-header'><span class='icon'>📁</span><span class='folder-name'> $archivo</span></div>";
            mostrarEstructura($rutaCompleta, $carpetaActual . "/" . $archivo);
            echo "</li>";
        } else {
            $extension = strtolower(pathinfo($archivo, PATHINFO_EXTENSION));
            $url = "../" . htmlspecialchars("$carpetaActual/$archivo");

            $id = md5($carpetaActual . "/" . $archivo);
            $dataId = htmlspecialchars($id);
            $dataCarpeta = htmlspecialchars($carpetaActual);
            $dataArchivo = htmlspecialchars($archivo);
            echo "<li class='file'>";
            echo "<span class='icon'>📄</span>";
            echo "<span class='file-name-preview'>";
            echo "<a href='$url' target='_blank'>$archivo</a>";
            echo "<button class='preview-btn' data-id='$dataId' data-carpeta='$dataCarpeta' data-archivo='$dataArchivo' data-extension='$extension' title='Previsualizar archivo'>🔍</button>";
            echo "</span>";
            echo "<div class='preview-content' id='preview-$id'></div>";
            echo "</li>";
        }
    }
    echo "</ul>";
}

// PREVISUALIZAR DOCUMENTO/PREVIEW DOCUMENT
if (isset($_GET['previsualizar'], $_GET['carpeta'], $_GET['archivo']) && $_GET['previsualizar'] == '1') {
    $carpeta = $_GET['carpeta'];
    $archivo = $_GET['archivo'];
    $ruta = __DIR__ . "/$carpeta/$archivo";

    if (!file_exists($ruta)) {
        header('Content-Type: application/json');
        echo json_encode(['error' => 'Archivo no encontrado.']);
        exit;
    }
// TIPO DE DOCUMENTO/ DOCUMENT TYPE
    $extension = strtolower(pathinfo($archivo, PATHINFO_EXTENSION));
$ext_img = ['jpg', 'jpeg', 'png', 'gif', 'svg', 'bmp', 'webp'];
$ext_pdf = ['pdf', 'doc', 'docx', 'odt']; // 

header('Content-Type: application/json');

if (in_array($extension, $ext_img)) {
    echo json_encode(['imagen' => "$carpeta/$archivo"]);
} 
elseif (in_array($extension, $ext_pdf)) {
    
    echo json_encode(['pdf' => "$carpeta/$archivo"]);
} 
else {
    $contenido = file_get_contents($ruta);
    echo json_encode(['contenido' => $contenido]);
}
exit;

}

// ARCHIVO PARA EJECUTAR/VIEW A FILE
if (isset($_GET['carpeta']) && isset($_GET['archivo']) && !isset($_GET['previsualizar'])) {
    $carpeta = $_GET['carpeta'];
    $archivo = $_GET['archivo'];
    $ruta = __DIR__ . "/$carpeta/$archivo";

    if (!file_exists($ruta)) {
        echo "<p>Archivo no encontrado.</p>";
        exit;
    }

    echo "<h2>Archivo: $archivo</h2>";
    $extension = pathinfo($archivo, PATHINFO_EXTENSION);

    if ($extension === "php") {
        header("Location: $carpeta/$archivo");
        exit;

    } elseif ($extension === "py") {
        echo "<h3>Contenido del archivo:</h3><pre>";
        echo htmlspecialchars(file_get_contents($ruta));
        echo "</pre>";

        echo "<h3>Salida del script (Python):</h3><pre>";
        $salida = shell_exec("python3 " . escapeshellarg($ruta) . " 2>&1");
        echo htmlspecialchars($salida);
        echo "</pre>";

    } elseif ($extension === "js") {
        echo "<h3>Contenido del archivo:</h3><pre>";
        echo htmlspecialchars(file_get_contents($ruta));
        echo "</pre>";

        echo "<h3>Salida del script (Node.js):</h3><pre>";
        $salida = shell_exec("node " . escapeshellarg($ruta) . " 2>&1");
        echo htmlspecialchars($salida);
        echo "</pre>";
    }

    echo '<p><a href="index.php">← Volver al índice</a></p>';
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8" />
<title>Inicio</title>
<link rel="icon" href="/img/kon.jpeg" type="image/png">
<link rel="stylesheet" href="style.css">

<!-- Highlight.js for code color/para resaltar código-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/styles/atom-one-dark.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/highlight.min.js"></script>
</head>
<body>
    
    <div id="tree-container">
    
    <div id="search-box" class="search-box">
    <input type="text" id="search-input" class="search-input" placeholder="Buscar archivo o carpeta...">
    </div>


    <?php
    foreach ($carpetas as $carpeta) {
		// FOR EACH PARA CARGAR CARPETA EN CARPETA/ FOR LOAD EACH FOLDER
        echo "<h2>$carpeta</h2>";
        if (is_dir($carpeta)) {
            echo "<div class='folder' onclick='toggleFolder(this)'>";
            echo "<div class='folder-header'><span class='icon'>📁</span><span class='folder-name'> $carpeta</span></div>";
            mostrarEstructura($carpeta, $carpeta);
            echo "</div>";
        } else {
            echo "<p>(Carpeta no encontrada)</p>";
        }
    }
    ?>
    </div>


    
<script src="script.js"></script> 
</body>
</html>
