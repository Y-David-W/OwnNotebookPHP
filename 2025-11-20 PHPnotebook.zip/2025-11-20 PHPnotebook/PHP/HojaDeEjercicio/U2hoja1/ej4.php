<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    $num = 5.5;
    $tipo = gettype($num);
    echo "$num es tipo $tipo<br>";
    $num2 = (int)$num;
    $tipo2 = gettype($num2);
    echo "$num2 es tipo $tipo2";
    // Se quita el .5 porque se convierte en numero entero
    ?>
</body>
</html>