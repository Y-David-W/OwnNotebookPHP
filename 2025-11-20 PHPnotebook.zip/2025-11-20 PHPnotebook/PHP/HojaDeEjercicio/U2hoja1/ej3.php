<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    $num = 5;
    $tipo = gettype($num);
    echo "$num es tipo $tipo<br>";
    $num = 5.5;
    $tipo = gettype($num);
    echo "$num es tipo $tipo";
    // Ahora es un double por que ve primero que tipo de variable es
    ?>
</body>
</html>