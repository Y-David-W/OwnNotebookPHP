<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>ORDENAR DADOS</h1><br>
    <?php
    $tirada = rand(2,7);
    $resultado = [];
    echo"<h3>Tirada de $tirada dados</h3><br>";
    for($i = 0; $i < $tirada; $i++){
        $num = rand(1,6);
        $resultado[] = $num;
        echo "<img src='dado/$num.png' width='100px' height='100px'> ";
    }

    echo"<br>";
    echo"<h3>Tirada ordenada</h3><br>";
    sort($resultado);
    // sort o asort para ascendente y rsort para descendente
    foreach($resultado as $num){
        echo "<img src='dado/$num.png' width='100px' height='100px'> ";
    }



    ?>

</body>
</html>