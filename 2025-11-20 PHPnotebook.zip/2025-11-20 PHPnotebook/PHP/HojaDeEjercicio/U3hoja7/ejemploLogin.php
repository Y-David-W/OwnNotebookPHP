<?php
/**********************************************************************
 * LOGIN SENCILLO EN UN SOLO ARCHIVO PHP
 * ------------------------------------------------------------
 * - Contiene formulario, validación, bienvenida, error y logout.
 * - Muestra directamente la página de bienvenida al iniciar sesión.
 * - Protege el acceso directo a la página de bienvenida.
 **********************************************************************/

// ------------------------------------------------------------
// 1️⃣ Iniciar o continuar la sesión (antes de cualquier HTML)
// ------------------------------------------------------------
session_start();

// ------------------------------------------------------------
// 2️⃣ Definir las credenciales válidas (ejemplo simple)
// ------------------------------------------------------------
$usuario_valido = 'usuario';
$clave_valida   = '1234';

// ------------------------------------------------------------
// 3️⃣ Si el usuario pulsa “Cerrar sesión”
// ------------------------------------------------------------
if (isset($_GET['pagina']) && $_GET['pagina'] === 'logout') {
    // Eliminar todos los datos de la sesión
    session_unset();
    session_destroy();

    // Redirigir al formulario de login
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit;
}

// ------------------------------------------------------------
// 4️⃣ Si se ha enviado el formulario (por método POST)
// ------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario = $_POST['usuario'] ?? '';
    $clave   = $_POST['clave'] ?? '';

    // Comprobar credenciales
    if ($usuario === $usuario_valido && $clave === $clave_valida) {
        // ✅ Credenciales correctas → crear sesión
        $_SESSION['usuario'] = $usuario;
    } else {
        // ❌ Credenciales incorrectas → marcar error
        $error = "Usuario o contraseña incorrectos.";
    }
}

// ------------------------------------------------------------
// 5️⃣ Si el usuario ya está logueado, mostrar bienvenida
// ------------------------------------------------------------
if (isset($_SESSION['usuario'])) {
    ?>
    <!doctype html>
    <html lang="es">
    <head>
        <meta charset="utf-8">
        <title>Bienvenido</title>
    </head>
    <body>
        <h1>Bienvenido, <?php echo htmlspecialchars($_SESSION['usuario']); ?> </h1>
        <p>Has iniciado sesión correctamente.</p>

        <!-- Botón para cerrar sesión -->
        <form method="get" action="">
            <input type="hidden" name="pagina" value="logout">
            <button type="submit">Cerrar sesión</button>
        </form>
    </body>
    </html>
    <?php
    exit; // detenemos aquí, no mostramos el login
}

// ------------------------------------------------------------
// 6️⃣ Si no está logueado, mostrar el formulario de login
// ------------------------------------------------------------
?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <title>Login sencillo</title>
</head>
<body>
    <h2>Iniciar sesión</h2>

    <!-- Mostrar mensaje de error si las credenciales no son correctas -->
    <?php if (!empty($error)) : ?>
        <p style="color:red;"><?php echo $error; ?></p>
    <?php endif; ?>

    <!-- Formulario de acceso -->
    <form method="post" action="">
        <label>Usuario:<br>
            <input type="text" name="usuario" required>
        </label><br><br>

        <label>Contraseña:<br>
            <input type="password" name="clave" required>
        </label><br><br>

        <button type="submit">Entrar</button>
    </form>
</body>
</html>
