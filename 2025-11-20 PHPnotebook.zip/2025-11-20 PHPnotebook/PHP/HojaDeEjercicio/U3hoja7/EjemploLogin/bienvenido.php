<?php
session_start();

// Comprobamos si el usuario llegó desde login.php
if (empty($_SESSION['autenticado'])) {
    // Si no pasó por login, lo mandamos de vuelta
    header("Location: index.html");
    exit;
}
?>
<!doctype html>
<html lang="es">
<head><meta charset="utf-8"><title>Bienvenido</title></head>
<body>
  <h1>✅ Bienvenido</h1>
  <p>Has iniciado sesión correctamente.</p>
  <a href="index.html">Cerrar sesión</a>
</body>
</html>
<?php
// Limpiamos la variable para evitar reentradas
unset($_SESSION['autenticado']);
?>
