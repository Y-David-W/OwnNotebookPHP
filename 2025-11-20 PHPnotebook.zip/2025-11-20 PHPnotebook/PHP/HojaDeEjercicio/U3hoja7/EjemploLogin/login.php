<?php
// Ejemplo de login sencillo con protección básica
session_start(); // Iniciamos sesión

// Usuario y contraseña válidos
$usuario_valido = "usuario";
$clave_valida   = "1234";

// Comprobar si se envió el formulario
if ($_POST['usuario'] == $usuario_valido && $_POST['clave'] == $clave_valida) {
    // Si los datos son correctos, guardamos en la sesión
    $_SESSION['autenticado'] = true;
    header("Location: bienvenido.php");
    exit;
} else {
    // Si son incorrectos, marcamos un error en la sesión
    $_SESSION['error'] = true;
    header("Location: error.php");
    exit;
}


/*

index.html (formulario)
       │
       ▼
login.php → verifica usuario y contraseña
       │
 ┌─────┴─────────────┐
 │                   │
 ▼                   ▼
bienvenido.php     error.php
(Protegido)        (Solo si hubo error)
 │                   │
 ▼                   ▼
index.html ← (cierra sesión o vuelve a intentar)

*/
?>