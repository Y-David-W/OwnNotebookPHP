<?php
session_start();

// Solo se muestra si se llegó desde login.php
if (empty($_SESSION['error'])) {
    header("Location: index.html");
    exit;
}
?>
<!doctype html>
<html lang="es">
<head><meta charset="utf-8"><title>Error</title></head>
<body>
  <h1>Usuario o contraseña incorrectos</h1>
  <a href="index.html">Volver a intentar</a>
</body>
</html>
<?php
// Borramos la marca de error al mostrar la página
unset($_SESSION['error']);
?>
