<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php

    $array_estadisticas = [1,2,3,4,5,6];
    
    function maximo($array){
        echo "el valor máximo es ".max($array);
    }
    function minimo($array){
        echo "el valor mínimo es ".min($array);
    }
    function suma(){}
    function media(){}


    unset($array_estadisticas[3]);
    foreach($array_estadisticas as $num){
        echo $num;
    }
    echo "<br>";
    maximo($array_estadisticas);

    ?>
</body>
</html>