<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    // CREAMOS EL ARRAY MULTIDIMENSIONA
    $animal = [
        ["estrella de mar", "estrella.png", "https://es.wikipedia.org/wiki/Asteroidea"],
        ["medusa", "medusa.png", "https://es.wikipedia.org/wiki/Medusozoa"],
        ["pez", "pez.png","https://es.wikipedia.org/wiki/Pez"],
    ];
    // CREAMOS ALEATORIDAD PARA ESCOGER UN ANIMAL
    $animalAleatorio = rand(0, count($animal) -1);
    ?>
    <section>
    <h1>FICHA INFORMATIVAS DEL ANIMALES</h1>
    Actualice la página para mostar un nuevo animal<br>
    <h3><?=$animal[$animalAleatorio][0]?></h3><br>
    <img src="animales/<?=$animal[$animalAleatorio][1]?>" width="100px" height="100px"><br>
    El información está aquí <a href="<?=$animal[$animalAleatorio][2]?>">wikipedia</a>
    </section>
    <style>
        section{
            border-style: solid;
            padding: 10px;
        }
    </style>
</body>
</html>