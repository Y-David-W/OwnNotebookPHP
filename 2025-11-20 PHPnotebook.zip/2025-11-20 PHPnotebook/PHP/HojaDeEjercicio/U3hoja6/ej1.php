<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario</title>
    <script>
        function borrarCampo() {
            document.formulario.nombre.value = "";
        }
    </script>
</head>
<body>
    <form name="formulario" action="GETej1.php" method="get">
        Escribe nombre: <input type="text" name="nombre"/><br>
        <input type="submit" value="Enviar" name="enviar"/>
        <input type="button" value="Borrar" onclick="borrarCampo()"/>
    </form>
</body>
</html>
