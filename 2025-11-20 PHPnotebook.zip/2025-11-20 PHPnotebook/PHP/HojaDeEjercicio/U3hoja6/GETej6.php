<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    $frutaElegido = $_GET["fruta"];
    ?>
    La fruta elegido es <?=$frutaElegido?><br>
    <img src="fruta/<?=$frutaElegido?>.png" width="100px" height="100px"><br>
    <a href="ej6.php">volver al inicio</a>
</body>
</html>