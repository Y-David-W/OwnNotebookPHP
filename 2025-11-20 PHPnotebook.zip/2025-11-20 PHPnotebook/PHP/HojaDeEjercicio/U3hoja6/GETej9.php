<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    $fondo = $_GET["colorFondo"];
    $letra = $_GET["colorLetra"];
    ?>
    <h1>Esto son los colores elegidos</h1><br>
    <p>Hola mundo!</p><br>
    <a href="ej9.php">volver al inicio</a>
</body>
<style>
    html{
        background-color: <?=$fondo?>;
    }
    p{
        color: <?=$letra?>;
    }
    h1{
        color: <?=$letra?>;
    }
</style>
</html>