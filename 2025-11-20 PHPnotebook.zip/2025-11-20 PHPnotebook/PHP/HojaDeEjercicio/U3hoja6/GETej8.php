<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    $nombre = $_GET["nombre"];
    $apellido = $_GET["apellido"];
    $edad = $_GET["edad"];
    $peso = $_GET["peso"];
    $sexo = $_GET["sexo"];
    $estado = $_GET["estado"];
    $aficiones = $_GET["aficiones"];
    ?>

    <section>
    <?php
    echo"$nombre<br>";
    echo"$apellido<br>";
    echo"$edad<br>";
    echo"$peso<br>";
    echo"$sexo<br>";
    echo"$estado<br>";
    echo gettype($aficiones);

    foreach ($aficiones as $aficcion){
    echo $aficcion."<br />";
    }
    ?>

    </section>
</body>
</html>