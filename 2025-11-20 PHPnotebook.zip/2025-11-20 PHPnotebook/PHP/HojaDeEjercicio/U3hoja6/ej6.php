<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form name="elegir" action="GETej6.php" method="get">
        <input type="radio" name="fruta" value="manzana">
        manzana<br>
        <input type="radio" name="fruta" value="platano">
        platano<br>
        <input type="radio" name="fruta" value="naranja">
        naranja<br>
        <input type="submit" value="enviar">
        <input type="button" value="borrar" onclick="borrarSeleccion()">
    </form>

    <script>
        function borrarSeleccion() {
            const radios = document.getElementsByName('fruta');
            radios.forEach(radio => radio.checked = false);
        }
    </script>

</body>
</html>