<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <section>
    <h1>DATOS PERSONALES (FORMULARIO)</h1><br>
    <form name="formulario" action="GETej8.php" method="get">
    <p>Escribe los siguientes datos:</p><br>

    <h3>Nombre:</h3>
    <input type="text" name="nombre"><br>

    <h3>Apellido:</h3>
    <input type="text" name="apellido"><br>

    <h3>Edad:</h3>
    <input type="quantity" name="edad"><br>

    <h3>Peso:</h3>
    <input type="quantity" name="peso"><br>

    <h3>Sexo:</h3>
    <input type="radio" name="sexo" value="hombre">Hombre<br>
    <input type="radio" name="sexo" value="mujer">Mujer<br>

    <h3>Estado civil:</h3>
    <input type="radio" name="estado" value="Soltero">Soltero<br>
    <input type="radio" name="estado" value="Casado">Casado<br>
    <input type="radio" name="estado" value="Otro">Otro<br>

    <h3>Aficiones:</h3>
    <input type="checkbox" name="aficiones[]" value="cine">Cine<br>
    <input type="checkbox" name="aficiones[]" value="literatura">Literatura<br>
    <input type="checkbox" name="aficiones[]" value="tebeos">Tebeos<br>
    <input type="checkbox" name="aficiones[]" value="Deporte">deporte<br>
    <input type="checkbox" name="aficiones[]" value="música">Música<br>
    <input type="checkbox" name="aficiones[]" value="televisión">Televisión<br>

    <input type="submit" value="Enviar"> <input type="reset" value="Borrar">

    </form>
    </section>

    <style>
    section {
        background-color: #81c6ffff;
        border-radius: 10px;
        width: 50%;
        height: fit-content;
        padding: 10px;
        margin: 50px auto;
        line-height: 1.5px;
    }
    </style>

</body>
</html>