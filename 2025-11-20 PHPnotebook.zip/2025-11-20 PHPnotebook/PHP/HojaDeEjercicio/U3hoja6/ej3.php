<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form name="cuadrado" action="GETej3.php" method="get">
    Escribe el tamaño: <input type="text" name="tamaño"/><br>
    Escribe el borde grosor: <input type="text" name="borde"/><br>
    <input type="submit" name="enviar"/>
    <input type="button" name="borrar" value="borrar" onclick="borrarCampo()"/>
    </form>

    <script>
        function borrarCampo(){
            document.cuadrado.tamaño.value = "";
            document.cuadrado.borde.value = "";
        }
    </script>
</body>
</html>