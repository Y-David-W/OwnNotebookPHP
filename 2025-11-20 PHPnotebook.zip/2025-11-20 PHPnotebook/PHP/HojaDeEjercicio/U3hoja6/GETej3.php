<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    $tamaño = $_GET["tamaño"];
    $borde = $_GET["borde"];
    ?>
    Muestra el cuadrado <?=$tamaño?>px de tamaño y <?=$borde?>px de grosor
    <div style="background-color: orange; width: <?=$tamaño?>px; height: <?=$tamaño?>px; border: solid <?=$borde?>px;"></div>
    <a href="ej3.php">volver al inicio</a>
</body>
</html>