<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form name="formulario" action="GETej2.php" method="get">
    Escribe el tamaño: <input type="text" name="tamaño"/><br>
    <input type="submit" value="Enviar" name="enviar"/>
    <input type="button" value="Borrar" onclick="borrarCampo()"/>
    <input type="reset" value="borrar">
    </form>

    <script>
        function borrarCampo(){
            document.formulario.tamaño.value = "";
        }
    </script>
</body>
</html>