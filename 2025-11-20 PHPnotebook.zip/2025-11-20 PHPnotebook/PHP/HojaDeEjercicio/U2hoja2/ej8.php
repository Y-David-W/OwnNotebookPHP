<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
$num1 = 7;
$num2 = 5;
$result = $num1; //7
$result += $num2++; //7+5 y despues n2 es 6
echo "$num1 $num2 $result<br>";
$num1 = 7;
$num2 = 5;
$result = &$num1; // 7
$result += ++$num2; //num2 es 6 y res y n1 es 13
echo "$num1 $num2 $result<br>";
$num1 = 7;
$num2 = 5;
$result = &$num1;
$result += ++$num1;
echo "$num1 $num2 $result<br>";
    ?>
</body>
</html>