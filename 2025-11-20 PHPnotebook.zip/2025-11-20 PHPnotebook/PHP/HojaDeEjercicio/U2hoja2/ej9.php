<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    
$num1 = 0;
$num2 = 0.0;
var_dump ($num1==$num2);
// DEVUELVE UN BOOLEAN FALSO PORQUE ES IGUAL

$num1 = 0;
$num2 = 0.0;
var_dump ($num1===$num2);
// FALSO PORQUE NO ES DEL MISMO TIPO UNO ES INT Y OTRO DOUBLE
    ?>
</body>
</html>