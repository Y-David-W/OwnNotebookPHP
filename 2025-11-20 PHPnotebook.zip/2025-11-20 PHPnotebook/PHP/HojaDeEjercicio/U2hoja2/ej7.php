<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    $valor1 = 8;
    $valor2 = 3;

    $suma = $valor1 + $valor2;
    $resta = $valor1 - $valor2;
    $producto = $valor1 * $valor2;
    $cociente = $valor1 / $valor2;
    $resto = $valor1 % $valor2;
    echo "VALOR 1 $valor1    VALOR2 $valor2<br>";
    $valor1++;
    $valor2--;
    echo "SUMA $suma <br>RESTA $resta <br>PRODUCTO $producto<br>COCIENTE $cociente <br>RESTO $resto <br>INCREMENTO1 $valor1 <br>DECREMENTO2 $valor2";

    
    ?>
</body>
</html>