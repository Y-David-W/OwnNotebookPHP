<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="ej1.css">
    <title>Document</title>
</head>
<body>
    <?php
    // Obtiene el pi con y con 4 decimales con format
    $pi_4 = number_format(pi(), 4);
    echo "$pi_4<br>";
    $radio = 5; //Escribir el radio
    $perimetro = $pi_4*$radio;
    $area = $pi_4*(pow(2,$radio));
    echo "EL RÁDIO ES $radio<br>EL PERIMETRO ES $perimetro<br>EL ÁREA ES $area"
    ?>
</body>
</html>