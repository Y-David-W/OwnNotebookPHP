<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>BUSCADOR</h1><br>
    <p>Busca palabras claves de la lista</p><br>
    <form name="buscador" action="ej3.php" method="get">
        <input type="search" name="buscador">
        <input type="submit" value="Buscar">
    </form>

    <?php
    $palabra = $_GET["buscador"];

    $array_objeto = ["cebolla", "cevada", "tomate", "toronja", "tomate frito", "manzana"];

    if(empty($palabra)){
    echo"<li>";
    foreach($array_objeto as $objeto){    
        echo "<ol>$objeto</ol>";
    }
    echo"</li>";
    }else{

        echo"<li>";
        foreach($array_objeto as $objeto){
            if(preg_match("/\w*$palabra\w*/i", subject: $objeto)){
                echo"<ol>$objeto</ol>";
            }
            
        }
        echo"</li>";
    }

    ?>
</body>
</html>