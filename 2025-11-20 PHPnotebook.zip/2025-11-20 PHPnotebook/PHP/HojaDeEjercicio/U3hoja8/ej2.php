<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>TRADUCTOR A PIG LATIN</h1>

    <form name="traductor" action="ej2.php" method="get">
    <br><input type="text" name="frase">
    <br><input type="submit" value="Traducir">
    <input type="reset" value="Borrar">
    </form>
    <br>
    <?php
    // VARIABLES
    $frase = $_GET["frase"];
    $array_palabra = explode(" ", $frase);//SEPARA PALABRA
    $array_traducido = [];
    foreach($array_palabra as $palabra){

        if($palabra == ""){continue;}

        if(preg_match('/^[aeiouAEIOU]/', $palabra)){
            $array_traducido[] = $palabra."ay";
            
        }else{

            // CAMBIA EL VOCAL HASTA EL FINAL
            
            for($i = 0; $i < strlen($palabra); $i++){
                if(preg_match('/^[aeiouAEIOU]/', $palabra)){break;}
                // Mueve hasta el final
                $palabra = substr($palabra,1).$palabra[0];
            }
            $array_traducido[] = $palabra."ay";
            //$palabra = $palabra."ay";
        }
    }

    foreach($array_traducido as $palabra){
        echo"$palabra ";
    }


    ?>
</body>
</html>