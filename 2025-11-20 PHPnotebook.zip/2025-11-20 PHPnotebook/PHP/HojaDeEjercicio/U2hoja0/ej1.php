<?php
echo "<html>";
echo "<body>";
echo "<p>Hola mundo</p>";
echo "</body>";
echo "</html>";
?>