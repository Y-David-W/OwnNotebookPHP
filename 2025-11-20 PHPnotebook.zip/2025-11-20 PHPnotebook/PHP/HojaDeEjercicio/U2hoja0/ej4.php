<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style4.css">
    <title>Document</title>
</head>
<body>
    <div class="caja">
        <h1>Dado digital</h1>
        Actualice la página para un nuevo valor
        <div class="dado">
        <?php
        echo rand(1,6), "\n";
        ?>
        </div>
    </div>
</body>
</html>