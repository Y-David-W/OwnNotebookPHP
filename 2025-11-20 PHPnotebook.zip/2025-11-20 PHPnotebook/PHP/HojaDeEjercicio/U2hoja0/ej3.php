<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="style3.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div class="caja">
    <?php
    echo "<h1>Mi segundo programa</h1>";
    echo "<p><a href='ej2.php'>Ir al saludo</a></p>";
    ?>
    </div>
</body>
</html>