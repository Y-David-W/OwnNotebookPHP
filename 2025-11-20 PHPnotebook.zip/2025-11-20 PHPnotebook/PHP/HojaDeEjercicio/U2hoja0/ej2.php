<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="style2.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<div class="caja">
    <h1>Mi primer programa</h1>
    <p>Segundo fragmento</p>
    <?php
    echo "<p>HolaMundo</p>";
    echo "<p>Segundo fragmento</p>";
    ?>
</div>
</body>
</html>