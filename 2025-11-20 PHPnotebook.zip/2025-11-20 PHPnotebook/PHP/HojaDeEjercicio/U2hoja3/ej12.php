<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<!--tr para crear fila td/th celda-->
<!-- REAL ES FLOAT     CADENA STRING-->
    <table>
  <tr>
    <td>Tipo origen</td>
    <td>Tipo destino</td>
    <td>Posible?</td>
    <td>En que caso?</td>
  </tr>
  <tr>
    <td>Entero</td>
    <td>Real</td>
    <td>Si</td>
    <td>Siempre</td>
  </tr>
  <tr>
    <td>Entero</td>
    <td>Cadena</td>
    <td>Si</td>
    <td>Siempre</td>
  </tr>
  <tr>
    <td>Real</td>
    <td>Entero</td>
    <td>Si</td>
    <td>Siempre</td>
  </tr>
  <tr>
    <td>Real</td>
    <td>Cadena</td>
    <td>Si</td>
    <td>SIempre</td>
  </tr>
  <tr>
    <td>Cadena</td>
    <td>Entero</td>
    <td>Depende</td>
    <td>Si solo es numerico</td>
  </tr>
  <tr>
    <td>Cadena</td>
    <td>Real</td>
    <td>Depende</td>
    <td>Si solo es numerico o con decimales</td>
  </tr>

</table>
</body>

<style>
  table, th, td {
    border: 1px solid black; 
    border-collapse: collapse; 
  }
  th, td {
    padding: 8px; 
    text-align: left;
  }
</style>

</html>