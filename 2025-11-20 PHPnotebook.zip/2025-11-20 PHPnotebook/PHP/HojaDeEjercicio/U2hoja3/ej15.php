<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    $car1 = rand(1,10);
    $car2 = rand(1,10);
    $car3 = rand(1,10);
    
    ?>
    <h1>Carta más alta</h1>
    <img src="cartas/<?=$car1?>.png">
    <img src="cartas/<?=$car2?>.png">
    <img src="cartas/<?=$car3?>.png">
    <br>
    <?php
    echo"$car1 , $car2 , $car3 <br>";

    if ($car1 >= $car2){
        if($car1 >= $car3){
            echo "La mayor carta es la $car1";
        }else{echo "La mayor carta es la $car3";}
    }else{
        if($car2 >= $car3){
            echo "La mayor carta es la $car2";
        }else{
            echo "La mayor carta es la $car3";}
    }

    // max(2, 3, 1, 6, 7)
    ?>
</body>
</html>