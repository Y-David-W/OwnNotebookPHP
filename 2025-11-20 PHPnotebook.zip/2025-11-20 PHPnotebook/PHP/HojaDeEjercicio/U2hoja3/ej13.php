<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="ej13.css">
</head>
<body>
    <section>
    <?php
    $linea = rand(10,1000);
    ?>
    <h1>Línea</h1>
    Actualice para una nueva línea
    <br>
    Longituz: <?php echo $linea;?>
    <br>
    <div style="width: <?php echo $linea;?>px; height: 5px;background-color: black; position: relative;"></div>

    </section>
</body>
</html>