<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    $num1 = "7";
    $num2 = 5;
    // INT VAL HACE QUE SE CONVIERTA EN UN INT
    $result = intval($num1)/$num2;
    // num1 se conviete en 7 y resultado es igual a 7 dividido entre 5
    echo "$num1 / $num2 / $result<br>";
    
    $num1 = "LOTE: ";
    $num2 = 724;
    // CONCADENA EL NUM1 Y NUM2
    $result = $num1.$num2;
    echo "$num1 / $num2 / $result";
    
    
    ?>
</body>
</html>