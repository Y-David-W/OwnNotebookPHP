<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
        <section>
        <h1>Código de color</h1>
        <?php
        // VARIABLES
        $r = rand(0,255);
        $g = rand(0,255);
        $b = rand(0,255);

        echo "El color (r, g, b) aleatorio es: <br>";
        echo "Color (".$r.", ".$g.", ".$b.")";
        //echo "<div style='background-color: rgb(1, 1, 1);'> a </div>";
        ?>
        <div style="border-radius: 100%; background-color: rgb(<?php echo $r,",",$g,",",$b;?>); width: 100px; height: 100px;"> </div>
    </section>

    <style>
    section{
    background-color: rgba(186, 255, 246, 1);
    padding: 10px;
    border-radius: 10px;
    }
    </style>
</body>
</html>