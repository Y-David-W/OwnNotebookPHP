<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>CIRCULOS ALEATORIO</h1> <br>
    Genera círculos aleatorio de 1 a 10 <br>
    <?php
    $cantidad = rand(1,10);
    function CrearCirculo(){
        global $cantidad;
        for ($i= 0; $i< $cantidad; $i++){
        echo"<td style = 'border: 1px solid black;'><svg width='80' height='80'><circle cx='40' cy='40' r='40' fill='red' /></svg></td>";
        }
    }
    /*
    Escriba un programa que dibuje entre 1 y 10 círculos negros (al azar) en una fila de
    tabla.
    */
    echo"$cantidad círculos";

    ?>
    <table style = "border: 1px solid black;">
        <tr>
            <?=CrearCirculo()?>

        </tr>
    </table>
    
</body>
</html>