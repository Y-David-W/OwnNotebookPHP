<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    $cantidad = rand(1,10);
    function GenerarCirculo(){
        global $cantidad;
        for ($i = 0; $i < $cantidad; $i++) {
            $num=rand(1,10);
            $r = rand(0,255);
            $g = rand(0,255);
            $b = rand(0,255);
            
            $rot = rand(0,80)."deg" ;
            print"<td style='border: 1px solid black;'><svg  style='transform: rotate($rot);' width='60' height='60'>";
            print"<circle cx='30' cy='30' r='30' fill='rgb($r,$g,$b)'/>";
            print"<text x='30' y='40' text-anchor='middle' alignment-baseline='middle' font-size='32' fill='black'>$num</text>";
            print "</svg></td>";
        }
    }
    ?>

    <h1>CÍRCULOS DE COLORES EN FILA</h1><br>
    <p>Cantidad de círculos son <?=$cantidad?></p>
    <table style='border: 1px solid black;'>
        <tr>
            <?=GenerarCirculo()?>

        </tr>
    </table>

</body>
</html>