<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    $cantidad = rand(1,10);
    function GenerarCirculo(){
        global $cantidad;
        for ($i = 0; $i < $cantidad; $i++) {
            $por1 = rand(0,100);
            //background-color: hwb(120deg 25% 75%);
            $por2 = rand(0,100);
            print"<td style='border: 1px solid black;'><svg width='60' height='60'>";
            print"<circle cx='30' cy='30' r='30' fill='hwb(200 $por1% $por2%)'>";
            print "</svg></td>";
        }
    }
    ?>

    <h1>CÍRCULOS DE COLORES EN FILA</h1><br>
    <p>Cantidad de círculos son <?=$cantidad?></p>
    <table style='border: 1px solid black;'>
        <tr>
            <?=GenerarCirculo()?>
        </tr>
    </table>

</body>
</html>