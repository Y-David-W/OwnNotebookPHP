<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Dados aleatorios</h1><br>
    <?php
    // TIRA 1 A 10 DADOS Y LUEGO DICE EL TOTAL
    $tiradas = rand(1,10);
    $resultado = 0;

    echo"Hizo $tiradas tiradas<br>";

    for($i = 1; $i <= $tiradas; $i++){
        $num = rand(1,6);
    ?>
    <img src="dado/<?=$num?>.png" width="100px" height="100px">
    <?php
        $resultado += $num;
    }
    echo "<br>";
    echo "La suma es de $resultado";
    ?>
</body>
</html>