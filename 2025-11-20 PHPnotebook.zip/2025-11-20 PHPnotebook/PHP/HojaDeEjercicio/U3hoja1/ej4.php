<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>TRES DADOS</h1>
    <br>
    Actualiza la página para lanzar de nuevo
    <br>
    <?php
    $dado1 = rand(1,6);
    $dado2 = rand(1,6);
    $dado3 = rand(1,6);
    ?>
    <img src="dado/<?=$dado1;?>.png" width="100" height="100">
    <img src="dado/<?=$dado2;?>.png" width="100" height="100">
    <img src="dado/<?=$dado3;?>.png" width="100" height="100"><br>
    <?php
    if($dado1==$dado2 && $dado1 == $dado3) {
        echo "Es un trío de $dado1";
    }elseif($dado1==$dado2 || $dado1 == $dado3 || $dado3 == $dado2){
        if($dado1 == $dado2){
            echo "Has sacado un doble $dado1";
        }elseif($dado1 == $dado3){
            echo "Has sacado un doble $dado1";
        }else{
            echo "Has sacado un doble $dado2";
        }
    }else{
        echo "No hay dado comunes";
    }
    ?>
</body>
</html>