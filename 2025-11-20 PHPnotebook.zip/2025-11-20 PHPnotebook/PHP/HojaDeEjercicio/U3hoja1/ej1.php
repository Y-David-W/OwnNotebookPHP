<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>DOS DADOS</h1>
    <br>
    Actualiza la página para lanzar de nuevo
    <br>
    <?php
    $dado1 = rand(1,6);
    $dado2 = rand(1,6);
    ?>
    <img src="dado/<?=$dado1;?>.png" width="100" height="100">
    <img src="dado/<?=$dado2;?>.png" width="100" height="100"><br>
    <?php
    if($dado1==$dado2) {
        echo "Ambos han sacado $dado1";
    }elseif($dado1>$dado2) {
        echo"No es parejo, el valor más alto es $dado1";
    }else{
         echo"No es parejo, el valor más alto es $dado2";
    }
    ?>
</body>
</html>