<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>JUEGO: DADO MÁS ALTO</h1>
    <br>
    Actualiza la página para lanzar de nuevo
    <br>
    <?php
    $dado1 = rand(1,6);
    $dado2 = rand(1,6);
    $dado3 = rand(1,6);
    $dado4 = rand(1,6);

    $res1 = $dado1 + $dado2;
    $res2 = $dado3 + $dado4;
    ?>
    <table>
        <tr>
            <th>Jugador1</th>
            <th>Jugador2</th>
        </tr>
        <tr>
            <th>
                <img class="dado1" src="dado/<?=$dado1;?>.png" width="100" height="100">
                <img class="dado1" src="dado/<?=$dado2;?>.png" width="100" height="100">
            </th>
            <th>
                <img class="dado2" src="dado/<?=$dado3;?>.png" width="100" height="100">
                <img class="dado2" src="dado/<?=$dado4;?>.png" width="100" height="100">
            </th>
        </tr>
    </table>

    <br>
    <?php
    if($dado1 == $dado2 || $dado3==$dado4) {
        if($dado1 == $dado2 && $dado3 != $dado4) {
            echo"Ha ganado el jugador 1";
        }elseif($dado3 == $dado4 && $dado1 != $dado2) {
            echo "Ha ganado el jugador 2";
        }else{
            if($dado1 == $dado3){
                echo "Ha sido empate";
            }elseif ($dado1 > $dado3){
                echo "Ha ganado el jugador 1";
            }else{echo "Ha ganado el jugador 2";}
        }
    }else{
        if($res1 == $res2) {
            echo "Ha empatado";
        }elseif ($res1 > $res2) {
            echo "Ha ganado el jugador 1";
        }else{
            echo "Ha ganado el jugador 2";
        }
    }
    ?>
    <style>
        .dado1{
            background-color: blue;
            padding: 20px;
        }
        .dado2{
            background-color: red;
            padding: 20px;
        }
    </style>
</body>
</html>