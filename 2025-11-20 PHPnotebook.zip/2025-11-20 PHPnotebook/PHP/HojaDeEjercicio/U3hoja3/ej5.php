<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
    pre{
        font-size: 30px;
    }
</style>
<body>
    <h1>CONVERTIDOR DE BINARIO A GRAY</h1>
    <?php
    // GENERA EL BINARIO ALEATORIAMENTE
    $cifras = 10;
    $binario = [];
    $gray = [];

    echo"<pre>BINARIO:";
    for($i = 0; $i < $cifras; $i++){
        $binario[] = rand(0,1);
    }

    foreach($binario as $digito){
        echo" ".$digito;
    }
    echo"<br>";
    //var_dump($binario);
    // CONVERTIR EN GRAY
    echo "GRAY:   ";
    for($i = 0; $i < $cifras; $i++){
        if($i == 0){
            $gray[] = $binario[$i];
            continue;
        }
        if($binario[$i] == $binario[$i-1]){
            $gray[] = 1;
        }else{
            $gray[] = 0;
        }
    }

    foreach($gray as $digito){
        echo" ".$digito;
    }
    echo "</pre>";
    ?>
</body>
</html>