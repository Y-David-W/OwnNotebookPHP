<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>NOMBRES DE ANIMALES</h1><br>
    3.1<br>
    <?php
    $fichero = ["estrella.png", "medusa.png", "pez.png"];
    $nombre = ["estrella de mar", "medusa", "pez"];
    $animal = rand(1,count($fichero)) -1;

    echo"El animal es un $nombre[$animal]<br>";
    echo"<img src='animales/$fichero[$animal]' width='100px' heigh='200px'><br>";
    



    
    $bidimensional = [
        ["estrella.png", "estrella de mar"],
        ["medusa.png","medusa"],
        ["pez.png","pez"],
    ];
    $animal = rand(1,count($bidimensional)) -1;
    echo"El animal es un ", $bidimensional[$animal][1], "<br>";
    echo"<img src='animales/",$bidimensional[$animal][0],"' width='100px' heigh='200px'>";
     
    ?>
</body>
</html>