<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
    pre{
        font-size: 30px;
    }
</style>
<body>
    <h1>BIT MÁS COMÚN</h1>
    <?php
    // GENERA EL BINARIO ALEATORIAMENTE
    $cifras = 10;

    $a = [];
    $b = [];
    $c = [];
    $r = [];

    echo"<pre>";
    for($i = 0; $i < $cifras; $i++){
        $a[] = rand(0,1);
        $b[] = rand(0,1);
        $c[] = rand(0,1);
    }

    echo "A:";
    foreach($a as $digito){
        echo" ".$digito;
    }
    echo"<br>";

        echo "B:";
    foreach($b as $digito){
        echo" ".$digito;
    }
    echo"<br>";

        echo "C:";
    foreach($c as $digito){
        echo" ".$digito;
    }
    echo"<br>";

    // RESULTADO
    $r = [];

    for($i = 0; $i < $cifras; $i++){
        $a[$i]+$b[$i]+$c[$i]>=2?$r[] = 1:$r[] = 0;
    }

        echo "R:";
    foreach($r as $digito){
        echo" ".$digito;
    }

    echo "</pre>";
    ?>
</body>
</html>