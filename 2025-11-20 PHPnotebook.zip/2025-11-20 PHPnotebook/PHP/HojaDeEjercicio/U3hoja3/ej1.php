<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<h1>DADO</h1><br>
Actualiza la página para la tirada<br>
    <?php
    $dado = rand(1,6);
    $num = [
        1=>"uno",
        2=> "dos",
        3=> "tres",
        4=> "cuatro",
        5=> "cinco",
        6=> "seis",
    ]
        
    ?>
    <img src ="dado/<?=$dado?>.png" width= "100px"><br>
    <?php
    echo "Ha sacado un $num[$dado]"
    ?>
</body>
</html>