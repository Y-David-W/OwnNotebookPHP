<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    $gesto = ["&#9995;","128075", "128406", "129306" ];
    $tono = ["127995","127996", "127997","127998","127999" ];
    ?>
    &#
    &#9995;
    &#127999;
</body>
</html>