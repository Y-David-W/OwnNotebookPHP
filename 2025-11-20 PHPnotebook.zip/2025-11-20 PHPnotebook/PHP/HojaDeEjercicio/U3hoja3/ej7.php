<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php

    echo"<h1>ELIMINA UN VALOR</h1> <br>";
    echo "Actualiza la página para iniciar una nueva tirada<br>";
    $tiradas = rand(1,10);
    echo "<h4>Tiradas de $tiradas dados</h4>";

    $registro = [];

    for ($i = 0; $i < $tiradas;$i++) {
        $num = rand(1,6);
        $registro[] = $num;
        echo"<img src='dado/$num.png' width='100px' height='100px'> ";
    }
    echo "<br>";
    // ELIMINA LOS DADOS 

    echo "<h4>Dados a eliminar</h4><br>";

    $eliminar = rand(1,6);
    echo"<img src='dado/$eliminar.png' width='100px' height='100px'>";
    for ($i = 0; $i < $tiradas;$i++) {
        if($registro[$i]==$eliminar){unset($registro[$i]);}
    }
    echo "<br>";
    // MUESTRA LOS RESTANTES
    echo "<h4>Restantes</h4><br>";
    foreach($registro as $res){
        echo"<img src='dado/$res.png' width='100px' height='100px'> ";
    }
    ?>
</body>
</html>