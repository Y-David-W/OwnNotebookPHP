<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    // SE PUEDE USAR <?= INTERROGACION>



    // OBTENER EL TIPO
    $num1 = 2;
    $tipo1 = gettype($num1);
    echo "$tipo1";
    echo "<br>";
    // CONCADENAR
    echo "EL NÚMERO ES ", 5.2;
    echo "<br>";
    // Para concadenar variable es $var1.$var2

    // VALOR ALEATORIO
    echo rand(2,7), "\n";

    // CAMBIAR UN INT A DOUBLE Y BICEVERSA

    $num2 = 5.2;
    $tipo2 = (int)$num2; //string o double tambien se puede
    echo "$tipo2 / $num2";
    // tambien se puede con intval($variable);
    echo "<br>";
    
    //SE PUEDE METER PHP EN UN ETIQUETA HTML
    $expresion = false;
    ?>

    <?php if ($expresion == true): ?>
    Esto se mostrará si la expresión es verdadera.
    <?php else: ?>
    En caso contrario se mostrará esto.
    <?php endif; ?>
</body>
</html>