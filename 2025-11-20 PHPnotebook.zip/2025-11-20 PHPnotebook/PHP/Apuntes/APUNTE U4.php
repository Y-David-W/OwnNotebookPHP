<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    // ARRAY SIMPLE

    $array1 = array(
    "foo" => "bar",
    "bar" => "foo",
    // SE PUEDE MEZCLAR VARIOS TIPOS DE VARIABLE
    2=> "hola",
    );

    echo $array1[2], "<br>";

    //var_dump($array1); //PARA VER LOS VARIABLES
    //$array2 = array(1,2,3,4,5); también se puede
    $array2 = [1,2,3,4,5];
    //print_r($array2);
    echo"$array2[1]". "<br>";

    // ARRAY BIDIMENSIONAL

    $array3 = [
        [2, 'Jane'],
        [5, 'Mark'],
    ];
    echo $array3[0][1];
    /*
    foreach ($source_array as [$id, $name]) {
        echo "{$id}: '{$name}'\n";
    }
    */

    /*
    count($array) cuenta

    foreach ($mi_array as $valor) {
        // hacer algo con $valor
    }
        recorre un array

// AÑADIR O ELIMINAR VALORES
    $frutas = ['manzana', 'banana'];
    $frutas[] = 'naranja';
    //$frutas ahora es ['manzana', 'banana', 'naranja']
    unset($frutas[1])

    //array_push añade
    $persona = [
    "nombre" => "Juan",
    "apellidos" => "Pérez",
    "edad" => 30,
    "ciudad" => "Madrid"
    // array_splice(1,2) elimina 
    //array_splice($colores, 1, 0, $nuevo_color);
];

// Ejemplo con la sintaxis tradicional array()
$contacto = array(
    "nombre" => "Ana",
    "telefono" => "123-456-7890"
);

// Acceder a un valor específico
echo $persona["nombre"]; // Salida: Juan
echo $contacto["telefono"]; // Salida: 123-456-7890


    */
    



echo "<pre>"; // Muestra los arrays de forma más legible


// 1. sort() - Ordena por valores (reindexa claves)

$numeros = [4, 2, 8, 6];
sort(array: $numeros);
echo "1️⃣ sort() - Ordenar valores (ascendente):\n";
print_r($numeros);


// 2. rsort() - Ordena descendente (reindexa claves)

$numeros = [4, 2, 8, 6];
rsort($numeros);
echo "\n2️⃣ rsort() - Ordenar valores (descendente):\n";
print_r($numeros);


// 3. asort() - Ordena por valores y mantiene las claves

$edades = ["Juan" => 25, "Ana" => 22, "Luis" => 30];
asort($edades);
echo "\n3️⃣ asort() - Ordenar por valor (ascendente, mantiene claves):\n";
print_r($edades);


// 4. arsort() - Ordena por valores descendente (mantiene claves)

$edades = ["Juan" => 25, "Ana" => 22, "Luis" => 30];
arsort($edades);
echo "\n4️⃣ arsort() - Ordenar por valor (descendente, mantiene claves):\n";
print_r($edades);


// 5. ksort() - Ordena por claves (ascendente)

$personas = ["c" => "Carlos", "a" => "Ana", "b" => "Beatriz"];
ksort($personas);
echo "\n5️⃣ ksort() - Ordenar por clave (ascendente):\n";
print_r($personas);


// 6. krsort() - Ordena por claves (descendente)

$personas = ["c" => "Carlos", "a" => "Ana", "b" => "Beatriz"];
krsort($personas);
echo "\n6️⃣ krsort() - Ordenar por clave (descendente):\n";
print_r($personas);

// 7. usort() - Ordenar con función personalizada

$numeros = [5, 10, 2, 8];
usort($numeros, function($a, $b) {
    return $b <=> $a; // Descendente
});
echo "\n7️⃣ usort() - Ordenar con función personalizada (descendente):\n";
print_r($numeros);


// 8. uasort() - Ordenar con función personalizada (manteniendo claves)

$productos = [
    "teclado" => 30,
    "monitor" => 200,
    "raton" => 25
];
uasort($productos, function($a, $b) {
    return $a <=> $b; // Ascendente
});
echo "\n8️⃣ uasort() - Ordenar valores con función personalizada (mantiene claves):\n";
print_r($productos);


// 9. uksort() - Ordenar por clave con función personalizada

$letras = ["z" => 1, "b" => 2, "a" => 3];
uksort($letras, function($a, $b) {
    return strcmp($a, $b); // Ascendente alfabéticamente
});
echo "\n9️⃣ uksort() - Ordenar por clave con función personalizada:\n";
print_r($letras);

echo "</pre>";


    ?>
</body>
</html>