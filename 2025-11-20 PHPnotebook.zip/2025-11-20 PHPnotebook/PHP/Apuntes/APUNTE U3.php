<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    
    /*
    ANOTACIONES
    */


    
    /*
    // FUNCIONES
    $a =1;
    function test(){
        //echo $a; es un error
        global $a;
        echo $a; //acceso a la global
        echo $b; 
    }
    test();
    */


    // for en php

    for ($i = 1; $i <= 10; $i++) {
    echo $i; //se puede break
    }

    // while y do while
    $i = 1;
    while ($i <= 10) {
        echo $i++;  /* El valor mostrado es $i antes del incremento
                   (post-incremento)  */
    }

    $i = 0;
    do {
        echo $i;
    } while ($i > 0);

    // if en php
    $edad = 20;
    if ($edad >= 18) {
        echo "Eres mayor de edad.";
    } //elseif ($edad >= 0) {}
    echo "<br>";

    // SWITCH EN PHP
    $i = 1;
    switch ($i) {
    case 0:
        echo "i igual 0";
        break;
    case 1:
        echo "i igual 1";
        break;
    case 2:
        echo "i igual 2";
        break;
    }  

    echo "<br>";

    $i = 5;
    $j = 3;
    switch ($i && $j) {
    case $i==$j:
        echo "Son igual";
        break;
    case $i>$j:
        echo "i > j";
        break;
    case $i<$j:
        echo "j > i";
        break;
    default:
        echo "Error";
        break;
    }  
    ?>



</body>
</html>