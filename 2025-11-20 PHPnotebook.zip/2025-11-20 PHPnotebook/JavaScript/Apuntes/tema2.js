/*
TIPOS DE VARIABLES

Los variables deben estar antes que los funciones

var: Las variables declaradas con var dentro de una función son locales a esa función.
Si se declaran fuera de cualquier función, son globales.

let: Las variables declaradas con let solo existen dentro del bloque {} más cercano.
Esto incluye bloques if, for, while y funciones
let solo es accesible dentro del bloque {} donde fue declarada. 
pero no se inicializan automáticamente.

const: es como var pero no puede canbiar el valor

*/
var a = 1;

contar();
function contar(){
    for(let i=0; i<5; i++){
        console.log(i+1);
    }
}
